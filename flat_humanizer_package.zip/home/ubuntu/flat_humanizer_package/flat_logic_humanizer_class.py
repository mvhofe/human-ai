from src.humanizer_logic.preprocessor import TextPreprocessor
from src.humanizer_logic.analyzer import AICharacteristicAnalyzer
from src.humanizer_logic.transformer import TransformationEngine

class TextHumanizer:
    def __init__(self):
        self.preprocessor = TextPreprocessor()

    def humanize_text(self, raw_text: str, lexical_sub_rate: float = 0.15, style: str = "default") -> tuple[str, dict]:
        """
        Processes raw text through the full humanization pipeline.
        Returns the humanized text and the analysis results of the original text.
        style: "default" or "academic"
        """
        if not isinstance(raw_text, str) or not raw_text.strip():
            print("Input text is empty or invalid.")
            return raw_text, {}

        print(f"Original Text for Humanization (Style: {style}):\n{raw_text}\n")

        # 1. Preprocess the text
        print("Step 1: Preprocessing text...")
        preprocessed_sentences = self.preprocessor.preprocess_text(raw_text)
        if not preprocessed_sentences:
            print("Preprocessing resulted in no sentences. Returning original text.")
            return raw_text, {}

        # 2. Analyze the preprocessed text (original characteristics)
        print("\nStep 2: Analyzing original text characteristics...")
        analyzer = AICharacteristicAnalyzer(preprocessed_sentences)
        original_analysis_results = analyzer.run_all_analyses()
        # print("Original Analysis Results:") # Keep this less verbose for API use
        # for key, value in original_analysis_results.items():
        #     print(f"  {key}: {value}")

        # 3. Transform the text
        print(f"\nStep 3: Applying transformations (Style: {style})...")
        transformer = TransformationEngine(preprocessed_sentences, original_analysis_results)
        
        humanized_text_output = transformer.humanize(
            lexical_sub_rate=lexical_sub_rate, 
            style=style
        )
        
        # print(f"\nHumanization Complete.") # Keep this less verbose for API use
        return humanized_text_output, original_analysis_results

if __name__ == "__main__":
    humanizer_tool = TextHumanizer()

    sample_ai_text_1 = "The utilization of advanced computational paradigms facilitates the optimization of resource allocation. It is imperative that organizational stakeholders strategically leverage emergent technological solutions to enhance operational efficiencies. The aforementioned methodologies are anticipated to yield substantial performance improvements."
    
    sample_ai_text_2 = "This document provides an overview of the current situation. The situation is complex. We must consider all factors. The factors are numerous. The solution will require careful planning. Planning is essential for success. It isn't easy."

    print("--- Test Case 1 (Default Style) ---")
    humanized_1, analysis_1 = humanizer_tool.humanize_text(sample_ai_text_1, lexical_sub_rate=0.2, style="default")
    print(f"\nFinal Humanized Text 1 (Default):\n{humanized_1}")

    print("\n\n--- Test Case 1 (Academic Style) ---")
    humanized_1_academic, analysis_1_academic = humanizer_tool.humanize_text(sample_ai_text_1, lexical_sub_rate=0.1, style="academic")
    print(f"\nFinal Humanized Text 1 (Academic):\n{humanized_1_academic}")

    print("\n\n--- Test Case 2 (Default Style) ---")
    humanized_2, analysis_2 = humanizer_tool.humanize_text(sample_ai_text_2, lexical_sub_rate=0.25, style="default")
    print(f"\nFinal Humanized Text 2 (Default):\n{humanized_2}")

    print("\n\n--- Test Case 2 (Academic Style) ---")
    humanized_2_academic, analysis_2_academic = humanizer_tool.humanize_text(sample_ai_text_2, lexical_sub_rate=0.1, style="academic")
    print(f"\nFinal Humanized Text 2 (Academic):\n{humanized_2_academic}")

