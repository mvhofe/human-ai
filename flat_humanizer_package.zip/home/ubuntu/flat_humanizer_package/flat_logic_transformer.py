import nltk
import random
from nltk.corpus import wordnet

# Assuming preprocessor.py and analyzer.py are in the same directory
# from preprocessor import TextPreprocessor
# from analyzer import AICharacteristicAnalyzer

class TransformationEngine:
    def __init__(self, preprocessed_sentences: list[list[tuple[str, str, str]]], analysis_results: dict):
        """
        Initializes the transformation engine with preprocessed text and analysis results.
        preprocessed_sentences: List of sentences, each a list of (token, POS_tag, lemma) tuples.
        analysis_results: Dictionary containing results from AICharacteristicAnalyzer.
        """
        self.processed_sentences = [s[:] for s in preprocessed_sentences] # Work on a copy
        self.original_processed_sentences = preprocessed_sentences # Keep original for reference if needed
        self.analysis_results = analysis_results

    def _get_synonyms(self, word: str, pos_tag: str = None, style: str = "default") -> list[str]:
        """Gets synonyms for a word, optionally filtered by POS tag and style."""
        synonyms = set()
        wordnet_pos = None
        if pos_tag:
            if pos_tag.startswith("N"): wordnet_pos = wordnet.NOUN
            elif pos_tag.startswith("V"): wordnet_pos = wordnet.VERB
            elif pos_tag.startswith("J"): wordnet_pos = wordnet.ADJ
            elif pos_tag.startswith("R"): wordnet_pos = wordnet.ADV
        
        for syn in wordnet.synsets(word, pos=wordnet_pos):
            for lemma in syn.lemmas():
                syn_word = lemma.name().replace("_", " ")
                if syn_word.lower() != word.lower():
                    # Basic formality filter for academic style (very simplistic)
                    # This is a placeholder for a more sophisticated formality check.
                    # For now, we might prefer longer synonyms or avoid very common ones if academic.
                    if style == "academic":
                        if len(syn_word) > len(word) + 2: # Prefer slightly longer words
                             synonyms.add(syn_word)
                        # Avoid overly simplistic synonyms if possible (hard to automate well here)
                    else:
                        synonyms.add(syn_word)
        
        # If academic style yielded no specific synonyms, fall back to default behavior for that word
        if style == "academic" and not synonyms:
             for syn in wordnet.synsets(word, pos=wordnet_pos):
                for lemma in syn.lemmas():
                    syn_word = lemma.name().replace("_", " ")
                    if syn_word.lower() != word.lower():
                        synonyms.add(syn_word)

        return list(synonyms)

    def lexical_substitution(self, substitution_rate: float = 0.1, style: str = "default") -> list[list[tuple[str, str, str]]]:
        """
        Performs lexical substitution.
        style: "default" or "academic". Academic style will try to use more formal synonyms.
        """
        transformed_sentences = []
        avoid_substituting_pos = ["DT", "IN", "CC", "TO", "PRP", "PRP$", ".", ",", ":", "MD"]
        common_verbs_lemmas = ["be", "have", "do", "say", "get", "make", "go", "know", "take", "see", "come", "think", "look", "want", "give", "use", "find", "tell", "ask"]

        # For academic style, we might be even more conservative with common verbs or expand the list.
        if style == "academic":
            # Example: be more restrictive with substitutions of very common verbs
            pass # Current common_verbs_lemmas is a good start

        current_sentences_to_transform = [s[:] for s in self.processed_sentences]
        for sentence_data in current_sentences_to_transform:
            new_sentence = []
            for token, pos, lemma in sentence_data:
                should_substitute = False
                if pos not in avoid_substituting_pos and lemma.lower() not in common_verbs_lemmas and random.random() < substitution_rate:
                    should_substitute = True
                
                # For academic style, perhaps be more willing to substitute adjectives/adverbs if they are simple
                if style == "academic" and pos.startswith(("J", "R")) and random.random() < substitution_rate * 1.5: # Slightly higher chance for adj/adv
                    if lemma.lower() not in common_verbs_lemmas: # Ensure it's not a common verb lemma mis-tagged
                        should_substitute = True

                if should_substitute:
                    synonyms = self._get_synonyms(lemma, pos, style=style)
                    if synonyms:
                        chosen_synonym = random.choice(synonyms)
                        if pos == "NNP" or pos == "NNPS":
                            new_token = chosen_synonym.split(" ")[0].capitalize() + (" " + " ".join(chosen_synonym.split(" ")[1:]) if len(chosen_synonym.split(" ")) > 1 else "")
                        else:
                            new_token = chosen_synonym.lower()
                        new_sentence.append((new_token, pos, new_token.lower()))
                        continue
                new_sentence.append((token, pos, lemma))
            transformed_sentences.append(new_sentence)
        self.processed_sentences = transformed_sentences
        return transformed_sentences

    def manage_contractions(self, style: str = "default") -> list[list[tuple[str, str, str]]]:
        """Introduces contractions for default style, or aims to expand them for academic style (rudimentary)."""
        if style == "academic":
            # Basic Contraction Expansion (very simplified)
            # A more robust version would need a comprehensive list and handle edge cases.
            expansion_map = {
                "isn't": [("is", "VBZ"), ("not", "RB")],
                "aren't": [("are", "VBP"), ("not", "RB")],
                "wasn't": [("was", "VBD"), ("not", "RB")],
                "weren't": [("were", "VBD"), ("not", "RB")],
                "don't": [("do", "VBP"), ("not", "RB")],
                "doesn't": [("does", "VBZ"), ("not", "RB")],
                "didn't": [("did", "VBD"), ("not", "RB")],
                "haven't": [("have", "VBP"), ("not", "RB")],
                "hasn't": [("has", "VBZ"), ("not", "RB")],
                "hadn't": [("had", "VBD"), ("not", "RB")],
                "won't": [("will", "MD"), ("not", "RB")],
                "wouldn't": [("would", "MD"), ("not", "RB")],
                "can't": [("can", "MD"), ("not", "RB")],
                "cannot": [("can", "MD"), ("not", "RB")],
                "couldn't": [("could", "MD"), ("not", "RB")],
                "shouldn't": [("should", "MD"), ("not", "RB")],
                "i'm": [("I", "PRP"), ("am", "VBP")],
                "you're": [("you", "PRP"), ("are", "VBP")],
                "he's": [("he", "PRP"), ("is", "VBZ")],
                "she's": [("she", "PRP"), ("is", "VBZ")],
                "it's": [("it", "PRP"), ("is", "VBZ")],
                "we're": [("we", "PRP"), ("are", "VBP")],
                "they're": [("they", "PRP"), ("are", "VBP")],
                "i've": [("I", "PRP"), ("have", "VBP")],
                "you've": [("you", "PRP"), ("have", "VBP")],
                "we've": [("we", "PRP"), ("have", "VBP")],
                "they've": [("they", "PRP"), ("have", "VBP")],
                "i'll": [("I", "PRP"), ("will", "MD")],
                "you'll": [("you", "PRP"), ("will", "MD")],
                "he'll": [("he", "PRP"), ("will", "MD")],
                "she'll": [("she", "PRP"), ("will", "MD")],
                "it'll": [("it", "PRP"), ("will", "MD")],
                "we'll": [("we", "PRP"), ("will", "MD")],
                "they'll": [("they", "PRP"), ("will", "MD")],
                "i'd": [("I", "PRP"), ("would", "MD")], # Could also be 'had'
                "you'd": [("you", "PRP"), ("would", "MD")],
                "he'd": [("he", "PRP"), ("would", "MD")],
                "she'd": [("she", "PRP"), ("would", "MD")],
                "we'd": [("we", "PRP"), ("would", "MD")],
                "they'd": [("they", "PRP"), ("would", "MD")],
                "let's": [("let", "VB"), ("us", "PRP")]
            }
            transformed_sentences = []
            for sentence_data in self.processed_sentences:
                new_sentence_tokens = []
                for token, pos, lemma in sentence_data:
                    token_lower = token.lower()
                    if token_lower in expansion_map:
                        expanded_forms = expansion_map[token_lower]
                        for i, (exp_token, exp_pos) in enumerate(expanded_forms):
                            # Preserve original capitalization for first word if it was I'm, He's etc.
                            final_exp_token = exp_token
                            if token[0].isupper() and i == 0:
                                final_exp_token = exp_token[0].upper() + exp_token[1:]
                            new_sentence_tokens.append((final_exp_token, exp_pos, exp_token.lower()))
                    else:
                        new_sentence_tokens.append((token, pos, lemma))
                transformed_sentences.append(new_sentence_tokens)
            self.processed_sentences = transformed_sentences
            return transformed_sentences

        # Default style: Introduce contractions
        contraction_map = {
            ("is", "not"): "isn't", ("are", "not"): "aren't", ("was", "not"): "wasn't", ("were", "not"): "weren't",
            ("do", "not"): "don't", ("does", "not"): "doesn't", ("did", "not"): "didn't",
            ("have", "not"): "haven't", ("has", "not"): "hasn't", ("had", "not"): "hadn't",
            ("will", "not"): "won't", ("would", "not"): "wouldn't",
            ("can", "not"): "cannot", 
            ("could", "not"): "couldn't", ("should", "not"): "shouldn't",
            ("i", "am"): "I'm", ("you", "are"): "you're", ("he", "is"): "he's", ("she", "is"): "she's",
            ("it", "is"): "it's", ("we", "are"): "we're", ("they", "are"): "they're",
            ("i", "have"): "I've", ("you", "have"): "you've", ("we", "have"): "we've", ("they", "have"): "they've",
            ("i", "will"): "I'll", ("you", "will"): "you'll", ("he", "will"): "he'll", ("she", "will"): "she'll",
            ("it", "will"): "it'll", ("we", "will"): "we'll", ("they", "will"): "they'll",
            ("i", "would"): "I'd", ("you", "would"): "you'd", ("he", "would"): "he'd", ("she", "would"): "she'd",
            ("we", "would"): "we'd", ("they", "would"): "they'd",
            ("let", "us"): "let's"
        }
        transformed_sentences = []
        for sentence_data in self.processed_sentences:
            new_sentence_tokens = []
            i = 0
            while i < len(sentence_data):
                token1_data = sentence_data[i]
                token1_lower = token1_data[0].lower()
                if i + 1 < len(sentence_data):
                    token2_data = sentence_data[i+1]
                    token2_lower = token2_data[0].lower()
                    if (token1_lower, token2_lower) in contraction_map:
                        contracted_form = contraction_map[(token1_lower, token2_lower)]
                        if token1_data[0][0].isupper() and contracted_form[0].islower() and contracted_form != "let's":
                            contracted_form = contracted_form[0].upper() + contracted_form[1:]
                        new_pos = token1_data[1]
                        new_lemma = contracted_form.lower()
                        new_sentence_tokens.append((contracted_form, new_pos, new_lemma))
                        i += 2
                        continue
                new_sentence_tokens.append(token1_data)
                i += 1
            transformed_sentences.append(new_sentence_tokens)
        self.processed_sentences = transformed_sentences
        return transformed_sentences

    def reconstruct_text(self) -> str:
        """Reconstructs the text from the (potentially transformed) processed sentences."""
        output_sentences = []
        for sentence_data in self.processed_sentences:
            sentence_str = ""
            for i, (token, pos, lemma) in enumerate(sentence_data):
                # Improved spacing logic
                if i == 0: # First token in sentence
                    sentence_str += token
                elif token in [".", ",", "?", "!", ";", ":"]: # Punctuation that attaches to previous word
                    sentence_str += token
                elif token.startswith("'") or token.lower() == "n't": # Contraction parts like 's, n't
                     sentence_str += token
                elif sentence_str and sentence_str[-1] in "(": # After an opening parenthesis
                    sentence_str += token
                else:
                    sentence_str += " " + token
            output_sentences.append(sentence_str.strip()) # Strip sentence just in case
        return " ".join(output_sentences)

    def humanize(self, lexical_sub_rate=0.15, style: str = "default") -> str:
        """Applies a sequence of transformations to humanize the text."""
        # Reset to original preprocessed sentences if multiple calls are made on same engine instance
        self.processed_sentences = [s[:] for s in self.original_processed_sentences]
        
        print(f"Original (for transformation engine input, style: {style}):")
        print(self.reconstruct_text())

        if lexical_sub_rate > 0:
            print(f"\nApplying lexical substitution (rate: {lexical_sub_rate}, style: {style})...")
            self.lexical_substitution(substitution_rate=lexical_sub_rate, style=style)
            print("After lexical substitution:")
            print(self.reconstruct_text())

        print(f"\nManaging contractions (style: {style})...")
        self.manage_contractions(style=style)
        print("After managing contractions:")
        print(self.reconstruct_text())
        
        print("\nFinal humanized text:")
        final_text = self.reconstruct_text()
        print(final_text)
        return final_text

if __name__ == '__main__':
    mock_processed_sentences_for_transformer = [
        [("It", "PRP", "it"), ("is", "VBZ", "be"), ("a", "DT", "a"), ("truth", "NN", "truth"), (".", ".", ".")],
        [("I", "PRP", "i"), ("will", "MD", "will"), ("not", "RB", "not"), ("do", "VB", "do"), ("it", "PRP", "it"), (".", ".", ".")],
        [("They", "PRP", "they"), ("are", "VBP", "be"), ("happy", "JJ", "happy"), (".", ".", ".")]
    ]
    mock_analysis_results_for_transformer = {}

    print("--- DEFAULT STYLE --- ")
    transformer_default = TransformationEngine([s[:] for s in mock_processed_sentences_for_transformer], mock_analysis_results_for_transformer)
    transformer_default.humanize(lexical_sub_rate=0.2, style="default")

    print("\n\n--- ACADEMIC STYLE --- ")
    transformer_academic = TransformationEngine([s[:] for s in mock_processed_sentences_for_transformer], mock_analysis_results_for_transformer)
    transformer_academic.humanize(lexical_sub_rate=0.1, style="academic")

    # Test contraction expansion
    mock_sentences_with_contractions = [
        [("It's", "PRP", "it's"), ("a", "DT", "a"), ("test", "NN", "test"), (".", ".", ".")],
        [("They", "PRP", "they"), ("won't", "MD", "won't"), ("come", "VB", "come"), (".", ".", ".")]
    ]
    print("\n\n--- ACADEMIC STYLE (with contraction input) --- ")
    transformer_academic_contractions = TransformationEngine([s[:] for s in mock_sentences_with_contractions], mock_analysis_results_for_transformer)
    transformer_academic_contractions.humanize(lexical_sub_rate=0.05, style="academic")

