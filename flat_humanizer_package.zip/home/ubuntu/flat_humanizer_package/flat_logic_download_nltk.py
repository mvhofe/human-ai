import nltk
import os

# Adjust path to be relative to this script's location if needed
# or ensure NLTK_DATA environment variable is set correctly.
# For simplicity, we assume nltk_data is in the default user location.

def download_nltk_resources_for_app():
    print(f"NLTK data path: {nltk.data.path}")
    resources_to_download = {
        "punkt": "tokenizers/punkt",
        "averaged_perceptron_tagger": "taggers/averaged_perceptron_tagger",
        "wordnet": "corpora/wordnet",
        "omw-1.4": "corpora/omw-1.4"
    }

    print("Ensuring standard NLTK resources are downloaded for the web app...")
    for resource_name, resource_path in resources_to_download.items():
        try:
            nltk.data.find(resource_path)
            print(f"Resource 	'{resource_name}'	 already available.")
        except LookupError:
            print(f"Resource 	'{resource_name}'	 not found. Downloading...")
            try:
                nltk.download(resource_name, quiet=False)
                print(f"Resource 	'{resource_name}'	 downloaded successfully.")
            except Exception as e:
                print(f"Failed to download resource 	'{resource_name}'	. Error: {e}")

    print("\nAttempting to resolve specific NLTK component dependencies for the web app...")
    specific_components = ["punkt", "punkt_tab", "averaged_perceptron_tagger", "averaged_perceptron_tagger_eng"]
    
    for component_name in specific_components:
        print(f"Checking/Downloading specific component: 	'{component_name}'	...")
        try:
            if component_name in ["punkt", "averaged_perceptron_tagger"]:
                 nltk.download(component_name, quiet=False, force=True)
            else:
                nltk.download(component_name, quiet=False)
            print(f"Component 	'{component_name}'	 check/download attempted successfully.")
        except ValueError as ve:
            print(f"Component 	'{component_name}'	 is not a recognized NLTK package name for direct download: {ve}")
        except Exception as e:
            print(f"Error downloading component 	'{component_name}'	: {e}")

if __name__ == "__main__": # This allows running it directly if needed
    print("Starting NLTK resource download process for web_humanizer_app...")
    download_nltk_resources_for_app()
    print("NLTK resource download process complete for web_humanizer_app.")

