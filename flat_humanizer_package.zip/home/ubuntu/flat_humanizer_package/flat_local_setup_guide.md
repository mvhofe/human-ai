# Local Setup and Usage Guide: Academic Text Humanizer Web App

## 1. Overview

This guide explains how to set up and run the Academic Text Humanizer web application on your local computer. The application is built using Python and Flask, with NLTK for natural language processing.

## 2. Prerequisites

Before you begin, ensure you have the following installed on your system:

*   **Python 3.11 or newer:** You can download Python from [python.org](https://www.python.org/downloads/). During installation, make sure to check the box that says "Add Python to PATH" (or similar, depending on your OS).
*   **pip:** Python's package installer. It usually comes with Python. You can check by opening a terminal or command prompt and typing `pip --version`.
*   **A modern web browser:** (e.g., Chrome, Firefox, Edge, Safari) to access the application.

## 3. Package Contents

The provided `web_humanizer_app_local_package.zip` file contains the following structure (among other files and folders):

```
web_humanizer_app/
|-- src/
|   |-- humanizer_logic/  # Core text processing Python modules
|   |-- models/           # (Standard Flask template, not used by this app)
|   |-- routes/           # API endpoint definitions
|   |-- static/           # Contains index.html (the frontend)
|   |-- main.py           # Main Flask application script
|-- requirements.txt      # List of Python dependencies
|-- README_LOCAL_SETUP.md # This guide
```

## 4. Setup Instructions

Follow these steps to set up the application:

### Step 1: Extract the Package

1.  Download the `web_humanizer_app_local_package.zip` file.
2.  Extract its contents to a folder on your computer (e.g., `C:\Users\YourName\Documents\web_humanizer_app` or `/home/yourname/web_humanizer_app`).

### Step 2: Open a Terminal or Command Prompt

Navigate to the extracted application directory. For example:

*   **Windows:** `cd C:\Users\YourName\Documents\web_humanizer_app\web_humanizer_app`
*   **macOS/Linux:** `cd /home/yourname/web_humanizer_app/web_humanizer_app`

(Note: The path might be nested one level deeper if the zip file contained a top-level `web_humanizer_app` folder. Adjust the `cd` command accordingly to be inside the directory that contains `requirements.txt` and the `src` folder.)

### Step 3: Create and Activate a Virtual Environment (Recommended)

Using a virtual environment keeps the project's dependencies isolated from your global Python installation.

1.  **Create the virtual environment:**
    ```bash
    python -m venv venv
    ```
    (If `python` defaults to Python 2 on your system, use `python3` or `python3.11` instead).

2.  **Activate the virtual environment:**
    *   **Windows (Command Prompt):**
        ```bash
        venv\Scripts\activate
        ```
    *   **Windows (PowerShell):**
        ```bash
        .\venv\Scripts\Activate.ps1
        ```
        (If script execution is disabled, you might need to run `Set-ExecutionPolicy Unrestricted -Scope Process` first, then `.\venv\Scripts\Activate.ps1`)
    *   **macOS/Linux (bash/zsh):**
        ```bash
        source venv/bin/activate
        ```
    Your terminal prompt should now indicate that you are in the `(venv)` environment.

### Step 4: Install Dependencies

With the virtual environment activated, install the required Python packages:

```bash
pip install -r requirements.txt
```
This command will read the `requirements.txt` file and install all necessary libraries, including Flask and NLTK.

### Step 5: Download NLTK Resources

The application uses NLTK for language processing, which requires specific data packages (corpora, taggers, etc.). The application includes a script to download these automatically when it starts. However, you can also run this manually if you prefer, or if the automatic download encounters issues (e.g., due to network restrictions).

To run it manually (ensure your virtual environment is active):
```bash
python src/humanizer_logic/download_resources.py
```
This will download resources like `punkt`, `averaged_perceptron_tagger`, `wordnet`, and `omw-1.4` to your NLTK data path (usually `~/nltk_data` on Linux/macOS or `C:\Users\YourName\AppData\Roaming\nltk_data` on Windows).

## 5. Running the Application

1.  Ensure your virtual environment is still active in the terminal and you are in the main application directory (where `src/main.py` is located).
2.  Start the Flask development server:
    ```bash
    python src/main.py
    ```
3.  You should see output similar to this:
    ```
    Checking/Downloading NLTK resources for the web app...
    NLTK data path: [...]
    Ensuring standard NLTK resources are downloaded for the web app...
    Resource    'punkt'     already available.
    ...
    NLTK resource check complete.
     * Serving Flask app 'main'
     * Debug mode: off
    WARNING: This is a development server. Do not use it in a production deployment.
     * Running on all addresses (0.0.0.0)
     * Running on http://127.0.0.1:5000
    Press CTRL+C to quit
    ```
4.  Open your web browser and go to the following address:
    [http://127.0.0.1:5000](http://127.0.0.1:5000)

## 6. Using the Application

Once the web page loads:

1.  **Input Text:** Paste or type the AI-generated text you want to humanize into the "Original Text" text area.
2.  **Humanize:** Click the "Humanize for Academic Thesis" button.
3.  **Output:** The "Humanized Text (Academic Style)" text area will display the transformed text. The style is preset for academic use (e.g., avoids contractions, aims for more formal vocabulary).
4.  **Analysis (Optional):** Below the humanized text, an "Analysis of Original Text" section will show some linguistic characteristics of the input text.

## 7. Stopping the Application

To stop the local server, go back to your terminal window where the Flask application is running and press `CTRL+C`.

## 8. Deactivating the Virtual Environment

When you are finished using the application, you can deactivate the virtual environment by typing:

```bash
deactivate
```

## 9. Troubleshooting

*   **`ModuleNotFoundError`:** Ensure your virtual environment is active and you have run `pip install -r requirements.txt` successfully.
*   **NLTK Resource Errors (`LookupError`):** If the application complains about missing NLTK resources even after starting, try running `python src/humanizer_logic/download_resources.py` manually from within the activated virtual environment. Ensure you have an internet connection.
*   **Port 5000 in use:** If another application is using port 5000, the Flask server might fail to start. You can either stop the other application or modify `src/main.py` to use a different port (e.g., `app.run(host='0.0.0.0', port=5001, debug=False)`).

Enjoy using the Academic Text Humanizer!
